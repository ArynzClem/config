import { watchFile, unwatchFile } from 'fs'
import chalk from 'chalk'
import { fileURLToPath } from 'url'
import moment from 'moment-timezone'

/*============= WAKTU =============*/
let wibh = moment.tz('Asia/Jakarta').format('HH')
    let wibm = moment.tz('Asia/Jakarta').format('mm')
    let wibs = moment.tz('Asia/Jakarta').format('ss')
    let wktuwib = `${wibh} H ${wibm} M ${wibs} S`    
    let d = new Date(new Date + 3600000)
    let locale = 'id'
    let weton = ['Pahing', 'Pon', 'Wage', 'Kliwon', 'Legi'][Math.floor(d / 84600000) % 5]
    let week = d.toLocaleDateString(locale, { weekday: 'long' })
    let date = d.toLocaleDateString(locale, {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    })

global.owner = [
  ['6283171750811', 'Итан Уинтерс', true], // Ganti No lu
  ['6283171750811', 'судно', true], // Ganti No Bot Lu
  ['6283171750811', 'Итан (владелец)', false] // Ganti No lu/hapus
] // nomor owner

global.mods = ['6288229683561'] // Ganti No Lu
global.prems = ['62882296835614','6288229683561', '79101481284'] // bebas (premium permanen)
global.APIs = { // API Prefix
  // name: 'https://website' 
  nrtm: 'https://fg-nrtm.ddns.net',
  lann: 'https://api.betabotz.eu.org'
}
global.APIKeys = { // APIKey Here
  // 'https://website': 'apikey'
  'https://api.betabotz.eu.org': 'YOUR APIKEY',
  'https://hoshiyuki-api.my.id': 'Hoshiyuki'
}

// daftar di sini https://api.betabotz.eu.org
global.lann = 'YOUR APIKEY'

// setting limit user
global.limit = 30

// Sticker WM
global.packname = 'Итан' 
global.author = '@Итан Уинтерс' 
//--info 
global.NSnama = 'судно'
global.NSig = 'https://www.instagram.com/' 
global.NSgc = 'https://whatsapp.com/channel/'
global.NSthumb = 'https://telegra.ph/file/9708607bb62a9b709c200.jpg'

// HIASAN
global.fla = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextType=1&fillTextPattern=Warning!&text=War%20Zone%20Game'
global.htki = '––––––『' 
global.htka = '』––––––' 
global.wm2 = '꒷︶꒷꒥꒷ ‧₊˚ ꒰ฅ˘лодкасудно˘ฅ ꒱ ‧₊˚꒷︶꒷꒥꒷'
global.snh = 'https://youtu.be/'
global.bottime = `T I M E : ${wktuwib}`
global.wait = '*⌛ _Loading..._*\n*▰▰▰▱▱▱▱▱*'
global.eror = 'Error, Неожиданная ошибка'
global.rwait = '⌛'
global.dmoji = '🤭'
global.done = '✅'
global.error = '❌' 
global.xmoji = '🔥' 

global.multiplier = 69 
global.maxwarn = '2' // max warning

let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
  unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  import(`${file}?update=${Date.now()}`)
})}`)
})