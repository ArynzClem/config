import fetch from 'node-fetch';

let handler = async (m, { text, usedPrefix, command }) => {
   try {
       if (!text) throw `Masukkan Command .call 8xxxx`;

       if (/@/.test(text)) {
           text = text.replace("@62", "");
       } else {
           text = text.replace("62", "");
       }

       const response = await fetch(`https://api.hoshiyuki-api.my.id/api/spam-call?nomor=${text}&apikey=Hoshiyuki`);
       if (!response.ok) {
           throw `Error: ${response.status} - ${response.statusText}`;
       }

       const result = await response.text();
       m.reply(result.trim());
   } catch (error) {
       const response = await fetch(`https://api.hoshiyuki-api.my.id/api/spam-call?nomor=${text}&apikey=Hoshiyuki`);
       const result2 = await response.text();
       m.reply(result2.trim());
   }
   
   if (m.chat.endsWith('@g.us')) {
       conn.reply(m.chat, `@${m.sender.split`@`[0]}`, m, { mentions: [m.sender] });
   }
};

handler.help = ['spamcall', 'call'];
handler.tags = ['premium'];
handler.command = /^(spamcall|call)$/i;
handler.premium = true;
handler.diamond = true;

export default handler;