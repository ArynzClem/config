import fetch from 'node-fetch'
import uploadImage from '../lib/uploadImage.js'

let handler = async (m, { conn, usedPrefix, command, text }) => {
let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
let name = await conn.getName(who)
let q = m.quoted ? m.quoted : m
let mime = (q.msg || q).mimetype || ''
if (!mime) throw 'Kirim/Reply Gambar Dengan Caption .toanime'
m.reply(wait)
let media = await q.download()
let url = await uploadImage(media)
let hasil = await (await fetch(`https://api.betabotz.eu.org/api/maker/jadianime?url=${url}&apikey=Hoshiyuki`)).json()
let res = await (await fetch(hasil.result.img_crop_single)).buffer()
await conn.sendFile(m.chat, res, '', 'Ciee Jadi Anime :v', m)
}
handler.help = ['toanime', 'jadianime']
handler.tags = ['maker']
handler.command = /^(jadianime|toanime)$/i
handler.diamond = 5
handler.premium = false

export default handler