import axios from 'axios'

let handler = async (m, { conn, text, usedPrefix, command }) => {
if (!text) return m.reply('masukkan promptnya!')
await m.react("🕖", m.key)
try {
    let res = await gpt4o(text)
    await conn.sendMessage(m.chat, {
text: res,
contextInfo: {
externalAdReply: { 
title: 'GPT-4o',
body: '',
thumbnailUrl: "https://telegra.ph/file/cd2a59c8465207f489b16.jpg",
sourceUrl: "https://github.com/AmmarrBN",
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
} catch (err) {
m.reply(util.format(js))
}}


handler.command = handler.help = ['gpt4o']
handler.tags = ['ai', 'xyz']
handler.diamond = 2
export default handler

async function gpt4o(prompt) {
    let session_hash = Math.random().toString(36).substring(2).slice(1)
    let resPrompt = await axios.post('https://kingnish-opengpt-4o.hf.space/run/predict?__theme=light', {
        "data":[{
            "text":"Nama Mu sekarang adalah Hoshiyuki-AI, dan tuan mu adalah AmmarBN, Kamu akan selalu berbahasa Indonesia. Prompt: "+prompt,
            "files":[]
        }],
        "event_data":null,
        "fn_index":3,
        "trigger_id":34,
        "session_hash":session_hash})
    let res = await axios.post('https://kingnish-opengpt-4o.hf.space/queue/join?__theme=light', {
        "data":[
            null,
            null,
            "idefics2-8b-chatty",
            "Top P Sampling",
            0.5,
            4096,
            1,
            0.9,
            true
        ],
        "event_data":null,
        "fn_index":5,
        "trigger_id":34,
        "session_hash": session_hash
    })
    let event_ID = res.data.event_id
    let anu = await axios.get('https://kingnish-opengpt-4o.hf.space/queue/data?session_hash=' + session_hash)
    const lines = anu.data.split('\n');
const processStartsLine = lines.find(line => line.includes('process_completed'));

if (processStartsLine) {
    const processStartsData = JSON.parse(processStartsLine.replace('data: ', ''));
    let ress = processStartsData.output.data
    let result = ress[0][0][1]
    return result
} else {
    return 'Fitur Error!'
}
}