const we = 20000
const diamond = 10
let cooldown = 2592000000 // 30 days in milliseconds
let handler = async (m, {conn}) => {

  let user = global.db.data.users[m.sender]
  if (!user.monthly) {
    user.monthly = 0
  }
  if (new Date() - user.monthly < cooldown) throw `⏱️ Kamu Sudah Mengklaim Hadiah Bulanan, Kamu dapat mengklaim nya lagi: \n *${msToTime((user.monthly + cooldown) - new Date())}*`
  user.coin += we
  user.diamond += diamond
  m.reply(`
🎁 ${mssg.monthly}

🪙 *${mssg.money}* : +${we.toLocaleString()}
💎 *${mssg.diamond}* : +${diamond}`)
  user.monthly = new Date().getTime()
}
handler.help = ['monthly']
handler.tags = ['econ']
handler.command = ['monthly', 'mensual']

export default handler

function msToTime(duration) {
  var milliseconds = parseInt((duration % 1000) / 100),
    seconds = Math.floor((duration / 1000) % 60),
    minutes = Math.floor((duration / (1000 * 60)) % 60),
    hours = Math.floor((duration / (1000 * 60 * 60)) % 24),
    days = Math.floor((duration / (1000 * 60 * 60 * 24)) % 365)

  hours = (hours < 10) ? "0" + hours : hours
  minutes = (minutes < 10) ? "0" + minutes : minutes
  seconds = (seconds < 10) ? "0" + seconds : seconds
  days = (days > 0) ? days : 0;

  return days + ` hari ` + hours + ` jam ` + minutes + ` menit`
}