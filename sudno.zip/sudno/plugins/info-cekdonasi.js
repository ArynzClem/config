import fetch from 'node-fetch';

let handler = async (m, { conn }) => {
    // Langkah 1: Melakukan masuk
    const loginData = {
        email: "nknoytsuba@gmail.com",
        password: "@mm4rgans"
    };
    
    const loginResponse = await fetch("https://backend.saweria.co/auth/login", {
        method: "POST",
        headers: {
            'Content-Type': 'application/json',
            'Host': 'backend.saweria.co',
            'sec-ch-ua': '"Google Chrome";v="123", "Not:A-Brand";v="8", "Chromium";v="123"',
            'sec-ch-ua-platform': '"Android"',
            'sec-ch-ua-mobile': '?1',
            'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Mobile Safari/537.36',
            'accept': '/',
            'origin': 'https://saweria.co',
            'sec-fetch-site': 'same-site',
            'sec-fetch-mode': 'cors',
            'sec-fetch-dest': 'empty',
            'referer': 'https://saweria.co/',
            'accept-encoding': 'gzip, deflate, br, zstd',
            'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7'
        },
        body: JSON.stringify(loginData)
    });
    
    const loginResult = await loginResponse.json();

    if (loginResult.status !== 'success') {
        return conn.reply(m.chat, "Login failed", m);
    }

    const token = loginResponse.headers.get('authorization');

    const HEADERS = {
        'host': 'backend.saweria.co',
        'sec-ch-ua': '"Google Chrome";v="123", "Not:A-Brand";v="8", "Chromium";v="123"',
        'sec-ch-ua-mobile': '?1',
        'authorization': token,
        'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Mobile Safari/537.36',
        'sec-ch-ua-platform': '"Android"',
        'accept': '/',
        'origin': 'https://saweria.co',
        'sec-fetch-site': 'same-site',
        'sec-fetch-mode': 'cors',
        'sec-fetch-dest': 'empty',
        'referer': 'https://saweria.co/',
        'accept-encoding': 'gzip, deflate, br, zstd',
        'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7'
    };

    const transactionResponse = await fetch('https://backend.saweria.co/transactions?page=1&page_size=15', {
        headers: HEADERS
    });

    const transactionResult = await transactionResponse.json();

    if (!transactionResult.data || !transactionResult.data.transactions) {
        return conn.reply(m.chat, "Failed to fetch transactions", m);
    }

    // Langkah 4: Menampilkan informasi tentang transaksi terbaru
    const transactions = transactionResult.data.transactions;
    const latestTransaction = transactions[0];
    const donorName = latestTransaction.donator_name;
    const totalDonation = latestTransaction.amount;
    const currency = latestTransaction.currency;

    // Tampilkan informasi tentang transaksi terbaru
    conn.reply(m.chat, `${donorName} telah mendonasikan sebesar ${totalDonation} ${currency}`, m);
}

handler.customPrefix = /^(.cekdonasi)$/i;
handler.command = new RegExp()

export default handler;