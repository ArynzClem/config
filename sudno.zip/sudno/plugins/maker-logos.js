import fetch from 'node-fetch'

let handler = async (m, { conn, args, text, usedPrefix, command }) => {
	
   let tee = `✳️ ${mssg.notext}\n\n📌 ${mssg.example}: *${usedPrefix + command}* nansoffc`
   let too = `✳️ ${mssg.textSe} *+* \n\n📌 ${mssg.example}: \n*${usedPrefix + command}* lann *+* ${NSnama}`
    m.react(rwait)

switch (command) {
	
	case 'giraffe':
	if (!text) throw tee
	let img = await (await fetch(`https://api.betabotz.eu.org/api/textpro/giraffe?text=${text}&apikey=${global.lann}`)).buffer()
	conn.sendFile(m.chat, img, 'nama.jpg', `Nih Mhank`, m, false)
	m.react(done)
	break 
	case 'neon': 
	if (!text) throw tee
	let ne = await (await fetch(`https://api.betabotz.eu.org/api/textpro/neon-green?text=${text}&apikey=${global.lann}`)).buffer()
	conn.sendFile(m.chat, ne, 'logo.png', `✅ Done Mhank`, m, false)
	m.react(done)
	break 
	
	case 'goldplaybutton': 
	if (!text) throw tee
	let tra = await (await fetch(`https://api.betabotz.eu.org/api/ephoto/ytgoldbutton?text=${text}&apikey=${global.lann}`)).buffer()
	conn.sendFile(m.chat, tra, 'logo.png', `✅ Done Mhank`, m)
	m.react(done)
	break
    case 'silverplaybutton': 
    if (!text) throw tee
    let sil = await (await fetch(`https://api.betabotz.eu.org/api/ephoto/ytsilverbutton?text=${text}&apikey=${global.lann}`)).buffer()
    conn.sendFile(m.chat, sil, 'logo.png', `✅ Done Mhank`, m)
    m.react(done)
    break

	case 'thunder': 
	if (!text) throw tee
	let thu = await (await fetch(`https://api.betabotz.eu.org/api/textpro/thunder?text=${text}&text2=&apikey=${global.lann}`)).buffer()
	conn.sendFile(m.chat, thu, 'logo.png', `✅ Done Mhank`, m)
	m.react(done)
	break 
	case 'graffiti': 
	if (!text) throw too
	//if (!text.includes('+')) throw too  
	//let [c, d] = text.split`+`
	let gff = await (await fetch(`https://api.betabotz.eu.org/api/textpro/grafity-text?text=${text}&apikey=${global.lann}`)).buffer()
	conn.sendFile(m.chat, gff, 'logo.png', `✅ Done Mhank`, m)
	m.react(done)
	break
	case 'blackpink': 
	if (!text) throw tee
	let bpin = await (await fetch(`https://api.betabotz.eu.org/api/ephoto/blackpink?text=${text}&apikey=${global.lann}`)).buffer()
	conn.sendFile(m.chat, bpin, 'logo.png', `✅ Done Mhank`, m)
	m.react(done)
	break 
	case 'papercut': 
	if (!text) throw tee
	let jok = await (await fetch(`https://api.betabotz.eu.org/api/ephoto/papercut?text=${text}&apikey=${global.lann}`)).buffer()
	conn.sendFile(m.chat, jok, 'logo.png', `✅ Done Mhank`, m)
	m.react(done)
	break 
	case 'matrix': 
	if (!text) throw tee
	let ma = global.API('lann', '/api/textpro/matrix', { text }, 'Hoshiyuki')
	conn.sendFile(m.chat, ma, 'logo.png', `✅ ${mssg.result}`, m)
	m.react(done)
	break 
	case 'wolf': 
   if (!text) throw tee
   let wo = global.API('lann', '/api/textpro/logowolf', { text: 'nansoffc', text2: text}, 'Hoshiyuki')
	conn.sendFile(m.chat, wo, 'logo.png', `✅ ${mssg.result}`, m)
	m.react(done)
	break
	case 'glow': 
	if (!text) throw tee
	let glo = global.API('lann', '/api/textpro/advancedglow', { text }, 'Hoshiyuki')
	conn.sendFile(m.chat, glo, 'logo.png', `✅ ${mssg.result}`, m)
	m.react(done)
	break 
	case 'phlogo': 
	if (!text) throw too
	if (!text.includes('+')) throw too  
	let [a, b] = text.split`+`   
	let ph = global.API('lann', '/api/textpro/pornhub', { text: a, text2: b}, 'Hoshiyuki')
	conn.sendFile(m.chat, ph, 'logo.png', `✅ ${mssg.result}`, m)
	m.react(done)
	break
	case 'ballon': 
	if (!text) throw tee
	let ball = global.API('lann', '/api/textpro/ballon', { text }, 'Hoshiyuki')
	conn.sendFile(m.chat, ball, 'logo.png', `✅ ${mssg.result}`, m)
	m.react(done)
	break
	case 'dmd': 
	if (!text) throw tee
	let dm = global.API('lann', '/api/textpro/diamond', { text }, 'Hoshiyuki')
	conn.sendFile(m.chat, dm, 'logo.png', `✅ ${mssg.result}`, m)
	m.react(done)
	break
	case 'lightglow': 
	if (!text) throw tee
	let lglo = global.API('lann', '/api/textpro/lightglow', { text }, 'Hoshiyuki')
	conn.sendFile(m.chat, lglo, 'logo.png', `✅ ${mssg.result}`, m)
	m.react(done)
	break 
	case 'american': 
	if (!text) throw tee
	let am = global.API('lann', '/api/textpro/American-flag', { text }, 'Hoshiyuki')
	conn.sendFile(m.chat, am, 'logo.png', `✅ ${mssg.result}`, m)
	m.react(done)
	break 
	case 'halloween': 
	if (!text) throw tee
	let hall = global.API('lann', '/api/textpro/halloween', { text }, 'Hoshiyuki')
	conn.sendFile(m.chat, hall, 'logo.png', `✅ ${mssg.result}`, m)
	m.react(done)
	break 
	case 'green': 
	if (!text) throw tee
	let hgre = global.API('lann', '/api/textpro/green-horror', { text }, 'Hoshiyuki')
	conn.sendFile(m.chat, hgre, 'logo.png', `✅ ${mssg.result}`, m)
	m.react(done)
	break 
	case 'glitch': 
	if (!text) throw tee
	let igli = global.API('lann', '/api/textpro/impressive-glitch', { text }, 'Hoshiyuki')
	conn.sendFile(m.chat, igli, 'logo.png', `✅ ${mssg.result}`, m)
	m.react(done)
	break
	
	case 'marvel': 
	if (!text) throw too
	if (!text.includes('+')) throw too  
	let [e, f] = text.split`+`   
	let marv = global.API('lann', '/api/textpro/marvel', { text: e, text2: f}, 'Hoshiyuki')
	conn.sendFile(m.chat, marv, 'logo.png', `✅ ${mssg.result}`, m)
	m.react(done)
	break
	case 'ninja': 
	if (!text) throw too
	if (!text.includes('+')) throw too  
	let [g, h] = text.split`+`   
	let nin = global.API('lann', '/api/textpro/ninja', { text: g, text2: h}, 'Hoshiyuki')
	conn.sendFile(m.chat, nin, 'logo.png', `✅ ${mssg.result}`, m)
	m.react(done)
	break
	case 'future': 
	if (!text) throw tee
	let futu = global.API('lann', '/api/textpro/futuristic', { text }, 'Hoshiyuki')
	conn.sendFile(m.chat, futu, 'logo.png', `✅ ${mssg.result}`, m)
	m.react(done)
	break
	case '3dbox': 
	if (!text) throw tee
	let box = global.API('lann', '/api/textpro/3dboxtext', { text }, 'Hoshiyuki')
	conn.sendFile(m.chat, box, 'logo.png', `✅ ${mssg.result}`, m)
	m.react(done)
	break
	case 'graffiti2': 
	if (!text) throw too
	if (!text.includes('+')) throw too  
	let [i, j] = text.split`+`
	let gff2 = global.API('lann', '/api/textpro/graffiti2', { text: i, text2: j}, 'Hoshiyuki')
	conn.sendFile(m.chat, gff2, 'logo.png', `✅ ${mssg.result}`, m)
	m.react(done)
	break 
	default:
} 
} 
handler.help = ['giraffe', 'graffiti2', '3dbox', 'future', 'ninja', 'marvel', 'glitch', 'halloween', 'green', 'american', 'neon', 'wolf', 'phlogo', 'goldplaybutton', 'silverplaybutton', 'thunder', 'graffiti', 'blackpink', 'papercut', 'matrix', 'glow', 'ballon', 'dmd', 'lightglow']
handler.tags = ['maker']
handler.command = /^(giraffe|graffiti2|3dbox|future|ninja|marvel|glitch|neon|green|halloween|american|wolf|phlogo|goldplaybutton|silverplaybutton|thunder|graffiti|blackpink|papercut|matrix|glow|ballon|dmd|lightglow)$/i
handler.diamond = true

export default handler