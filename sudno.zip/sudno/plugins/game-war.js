let handler = async (m, { conn, usedPrefix, args, command }) => {
  conn.war = conn.war ? conn.war : {}
  conn.war2 = conn.war2 ? conn.war2 : {}

  if (!args[0] || args[0] == "help") return m.reply(`*❏  W A R - Z O N E*

[1] War Zone adalah game perang dengan sistem _turn attack_ atau menyerang secara bergiliran
[2] Permainan dapat dimulai dengan 1v1 sampai dengan 5v5
[3] Modal perang adalah harta rampasan perang jika tim kamu menang
[4] Setiap pemain akan mendapatkan 5000 HP (Health Point)
[5] Keberhasilan menyerang tergantung level kamu dengan level musuh yang akan diserang
[6] Kesempatan menyerang adalah 40 detik, lebih dari itu dianggap AFK (pengurangan 2500 HP)
[7] Sebuah tim akan menang jika tim lawan kalah semua (HP <= 0) dan mendapatkan harta rampasan perang

*❏  C O M M A N D S*
*${usedPrefix + command} join A/B* = join game
*${usedPrefix + command} left* = left game
*${usedPrefix + command} coin 10xx* = coin taruhan
*${usedPrefix + command} player* = player game
*${usedPrefix + command} start* = start game`)

  if (args[0] == "coin"){
    if (!(m.chat in conn.war)) return m.reply(`*Silahkan buat room terlebih dahulu (Ketik .war join)*`)
    if(m.sender == conn.war[m.chat][0].user){
      if (args[1] != "undefined" && !isNaN(args[1])){
        args[1] = parseInt(args[1])
        if (args[1] < 1000) return m.reply('*Minimal 1000 coin*')
        conn.war2[m.chat].coin = args[1]
        return m.reply("*Berhasil menetapkan modal perang sebesar " + Number(args[1]).toLocaleString() + " coin*")
      }else {
        return m.reply("*Masukkan modal taruhan perang berupa angka (Tidak boleh menggunakan titik)*\n\n.war coin 100000")
      }
    }else {
      return conn.reply(m.chat,`*Hanya @${conn.war[m.chat][0].user.split('@')[0]} sebagai pembuat room yang bisa mengganti modal awal perang*`,m, {contextInfo : {mentionedJid : [conn.war[m.chat][0].user]}})
    }
  }

  // JOIN
  if (args[0] == "join"){
    
    if (global.db.data.users[m.sender].coin < 1000) return m.reply("*Koin kamu minimal 1000 untuk bermain game ini.*")
    // FIRST PLAYER
    if (!(m.chat in conn.war)) {
      conn.war2[m.chat] = {"war" : false, "turn" : 0, "time" : 0, "coin" : 0}
      conn.war[m.chat] = []
      let exp = global.db.data.users[m.sender].exp
      conn.war[m.chat][0] = {"user": m.sender, "hp": 5000, "lvl": global.db.data.users[m.sender].level, "turn" : false}
      for (let i=1;i<10;i++){
        conn.war[m.chat][i] = {"user": "", "hp" : 0, "lvl" : 0, "turn" : false}
      }
      return m.reply(`*Berhasil masuk ke dalam game sebagai Team A*\n\n*.war join a/b* = join game\n*.war start* = mulai game`)
    }else {   // NOT FIRST PLAYER
      // IF FULL
      if (conn.war2[m.chat].war) {
        return m.reply(`*Permainan sudah dimulai, tidak bisa join.*`)
      }
      // IF YOU ALREADY JOIN THE GAME
      for (let i = 0; i < conn.war[m.chat].length ; i++) {
        if (m.sender == conn.war[m.chat][i].user){
          let total = 0
          for (let i = 0 ; i < 10 ; i++) {
            if (conn.war[m.chat][i].user == ""){
              total += 1
            }
          }
          return m.reply(`*Anda sudah masuk ke dalam game*\n\n*.war join a/b* = join game\n*.war start* = mulai game`)
        }
      }
      
      // JOIN MILIH TIM
      if (args[1]){
        if (args[1].toLowerCase() == "a"){
          if (conn.war2[m.chat].coin == 0) return conn.reply(m.chat,`*Tolong @${conn.war[m.chat][0].user.split('@')[0]} tetapkan modal awal perang (minimal 1000000 coin)*\n\n.war coin 1000000`,m, {contextInfo : {mentionedJid : [conn.war[m.chat][0].user]}})
          if (global.db.data.users[m.sender].coin < conn.war2[m.chat].coin) return m.reply(`*Koin kamu minimal ${conn.war2[m.chat].coin.toLocaleString()} untuk bermain game ini.*`)
          for (let i = 1 ; i < 5 ; i++) {
            if (conn.war[m.chat][i].user == ""){
              let exp = global.db.data.users[m.sender].exp
              conn.war[m.chat][i] = {"user" : m.sender, "hp" : 5000, "lvl" : global.db.data.users[m.sender].level, "turn" : false}
              let total = 0
              for (let i = 0 ; i < 10 ; i++) {
                if (conn.war[m.chat][i].user == ""){
                  total += 1
                }
              }
              return m.reply(`*Berhasil masuk ke dalam game sebagai Team A*\n\n*.war join a/b* = join game\n*.war start* = mulai game`)
            }
          } 
        }else if (args[1].toLowerCase() == "b"){
          if (conn.war2[m.chat].coin == 0) return conn.reply(m.chat,`*Tolong @${conn.war[m.chat][0].user.split('@')[0]} tetapkan modal awal perang (minimal 1000000 coin)*\n\n.war coin 1000000`,m, {contextInfo : {mentionedJid : [conn.war[m.chat][0].user]}})
          if (global.db.data.users[m.sender].coin < conn.war2[m.chat].coin) return m.reply(`*Koin kamu minimal ${conn.war2[m.chat].coin.toLocaleString()} untuk bermain game ini.*`)
          for (let i = 5 ; i < 10 ; i++) {
            if (conn.war[m.chat][i].user == ""){
              let exp = global.db.data.users[m.sender].exp
              conn.war[m.chat][i] = {"user" : m.sender, "hp" : 5000, "lvl" : global.db.data.users[m.sender].level, "turn" : false}
              let total = 0
              for (let i = 0 ; i < 10 ; i++) {
                if (conn.war[m.chat][i].user == ""){
                  total += 1
                }
              }
              return m.reply(`*Berhasil masuk ke dalam game sebagai Team B*\n\n*.war join a/b* = join game\n*.war start* = mulai game`)
            }
          }
        }else {
          return m.reply(`*Pilih salah satu tim A atau B*\n\n.war join A\n.war join B`)
        }
      }else {
        // JOIN SESUAI URUTAN
        return m.reply(`*Pilih salah satu tim A atau B*\n\n.war join A\n.war join B`)
      }
      

      // CHECK IF ROOM FULL
      for (let i = 0 ; i < conn.war[m.chat].length ; i++) {
        let total = 0
        if (conn.war[m.chat][i].user != ""){
          total += 1
        }
        if (total == 10) conn.war2[m.chat].war = true
      }
    }
  }

  // LEFT GAME
  if (args[0] == "left"){
    // IF GAME START
    if (conn.war2[m.chat].war) {
      m.reply(`*Perang sudah dimulai, anda tidak bisa keluar*`)
    }else {   // IF NOT
      for (let i = 0 ; i < 10 ; i++) {
        if (m.sender == conn.war[m.chat][i].user){
          return m.reply(`*Berhasil keluar dari game*`)
        }
      }
      return m.reply(`*Kamu tidak sedang berada di dalam game*`)
    }
  }

  // CEK PLAYER
  if (args[0] == "player"){ 
    if (!(m.chat in conn.war)) return m.reply(`*Tidak ada pemain yang join room War Zone*`)
    var teamA = []
    var teamB = []
    var teamAB = []
    for (let i = 0; i < 10; i++) {
      let player = conn.war[m.chat][i]
      if (player.user != "") {
        if (i < 5) {
          teamA.push(`@${player.user.split('@')[0]} (HP: ${player.hp})`)
        } else {
          teamB.push(`@${player.user.split('@')[0]} (HP: ${player.hp})`)
        }
      }
    }
    if (teamA.length == 0 && teamB.length == 0) return m.reply(`*Tidak ada pemain yang join room War Zone*`)
    teamAB.push(`*Team A*\n${teamA.join('\n')}\n\n*Team B*\n${teamB.join('\n')}`)
    return conn.reply(m.chat, teamAB.join('\n\n'), m, { contextInfo: { mentionedJid: conn.war[m.chat].map(v => v.user) } })
  }

  // START GAME
  if (args[0] == "start") {
    if (!(m.chat in conn.war)) return m.reply(`*Tidak ada pemain yang join room War Zone*`)
    if (conn.war[m.chat][0].user != m.sender) return m.reply(`*Hanya pembuat room yang dapat memulai game*`)
    if (conn.war[m.chat].filter(v => v.user != "").length < 2) return m.reply(`*Jumlah pemain tidak cukup untuk memulai game*`)
    conn.war2[m.chat].war = true
    conn.war2[m.chat].turn = 0
    conn.war2[m.chat].time = new Date * 1
    return m.reply(`*Game War Zone dimulai!*\n\n*Team A*\n${conn.war[m.chat].slice(0, 5).filter(v => v.user != "").map(v => `@${v.user.split('@')[0]}`).join('\n')}\n\n*Team B*\n${conn.war[m.chat].slice(5).filter(v => v.user != "").map(v => `@${v.user.split('@')[0]}`).join('\n')}`, m, { contextInfo: { mentionedJid: conn.war[m.chat].map(v => v.user) } })
  }
}

handler.help = ['war']
handler.tags = ['game']
handler.command = /^war$/i

export default handler
