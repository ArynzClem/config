//import db from '../lib/database.js'
import { promises } from 'fs'
import { join } from 'path'
import fetch from 'node-fetch'
import { xpRange } from '../lib/levelling.js'
//import { plugins } from '../lib/plugins.js'
let tags = {
  'main': 'основной',
  'xyz': 'популер',
  'ai': 'опенак',
  'jadibot': 'собот',
  'game': 'игра',
  'econ': 'экономика',
  'rg': 'список',
  'sticker': 'наклейка',
  'img': 'изображение',
  'maker': 'создатель',
  'prem': 'премия',
  'group': 'группа',
  'nable': 'ENABLE/DISABLE', 
  'nime': 'аниме',
  'rnime': 'аниме реакция',
  'dl': 'загрузчик',
  'tools': 'инструменты',
  'fun': 'веселье',
  'cmd': 'базы данных',
  'owner': 'владелец', 
  'advanced': 'продвигать',
}
const defaultMenu = {
  before: `
╭──═[ *информация о пользователе* ]═──⋆
⬡│▸ Diamond ➠ limit & ⓓ
⬡│▸ Premium ➠ Ⓟ
│╭───────────────···
┴│▸ *Имя:* _%name_
⬡│▸ *уровень:* _%level_
⬡│▸ *предел:* _%diamond_
⬡│▸ *роль:* _%role_
⬡│▸ *дата:* _%date_
⬡│▸ *время безотказной работы :* _%muptime%_
┬│▸ *общее количество пользователей:* _%rtotalreg - %totalreg_
│╰────────────────···
╰───────═┅═───────
%readmore
`.trimStart(),
  header: '\`\`   \`%category\`',
  body: '* %cmd %isdiamond %isPremium',
  footer: '',
  after: NSnama,
}

let handler = async (m, { conn, usedPrefix: _p, args, __dirname }) => {

  let tags
  let teks = `${args[0]}`.toLowerCase()
  let arrayMenu = ['all', 'main', 'xyz', 'ai', 'jadibot', 'game', 'econ', 'rg', 'sticker', 'img', 'maker', 'prem', 'group', 'nable', 'nime', 'rnime', 'dl', 'tools', 'fun', 'cmd','owner', 'advanced']
  if (!arrayMenu.includes(teks)) teks = '404'
  if (teks == 'all') tags = {
    'main': 'основной',
    'xyz': 'популер',
    'ai': 'опенай',
    'jadibot': 'собот',
    'game': 'игра',
    'econ': 'экономика',
    'rg': 'список',
    'sticker': 'наклейка',
    'img': 'изображение',
    'maker': 'создатель',
    'prem': 'премия',
    'group': 'группа',
    'nable': 'ENABLE/DISABLE',
    'nime': 'аниме',
    'rnime': 'аниме реакция',
    'dl': 'загрузчик',
    'tools': 'инструменты',
    'fun': 'веселье',
    'cmd': 'базы данных',
    'owner': 'владелец',
    'advanced': 'продвигать',
  }
  if (teks == 'main') tags = {
    'main': 'основной',
    'nable': 'ENABLE/DISABLE',
  }
  if (teks == 'xyz') tags = {
    'xyz': 'популер'
  }
  if (teks == 'ai') tags = {
    'ai': 'опенай'
  }
  if (teks == 'jadibot') tags = {
    'jadibot': 'собот'
  }
  if (teks == 'game') tags = {
    'game': 'игра',
    'econ': 'экономика',
  }
  if (teks == 'sticker') tags = {
    'sticker': 'наклейка'
  }
  if (teks == 'img') tags = {
    'img': 'изображение'
  }
  if (teks == 'maker') tags = {
    'maker': 'создатель'
  }
  if (teks == 'prem') tags = {
    'prem': 'премия'
  }
  if (teks == 'group') tags = {
    'group': 'группа'
  }
  if (teks == 'nime') tags = {
    'nime': 'аниме'
  }
  if (teks == 'rnime') tags = {
    'rnime': 'аниме реакция'
  }
  if (teks == 'dl') tags = {
    'dl': 'загрузчик'
  }
  if (teks == 'tools') tags = {
    'tools': 'инструменты'
  }
  if (teks == 'fun') tags = {
    'fun': 'веселье'
  }
  if (teks == 'owner') tags = {
    'owner': 'владелец',
    'advanced': 'продвигать',
    'cmd': 'база данных',
  }

  try {
    let _package = JSON.parse(await promises.readFile(join(__dirname, '../package.json')).catch(_ => ({}))) || {}
    let { exp, diamond, level, role } = global.db.data.users[m.sender]
    let { min, xp, max } = xpRange(level, global.multiplier)
    let name = await conn.getName(m.sender)
    let d = new Date(new Date + 3600000)
    let locale = 'id'
    // d.getTimeZoneOffset()
    // Offset -420 is 18.00
    // Offset    0 is  0.00
    // Offset  420 is  7.00
    let weton = ['Pahing', 'Pon', 'Wage', 'Kliwon', 'Legi'][Math.floor(d / 84600000) % 5]
    let week = d.toLocaleDateString(locale, { weekday: 'long' })
    let date = d.toLocaleDateString(locale, {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    })
    let dateIslamic = Intl.DateTimeFormat(locale + '-TN-u-ca-islamic', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    }).format(d)
    let time = d.toLocaleTimeString(locale, {
      hour: 'numeric',
      minute: 'numeric',
      second: 'numeric'
    })
    let _uptime = process.uptime() * 1000
    let _muptime
    if (process.send) {
      process.send('uptime')
      _muptime = await new Promise(resolve => {
        process.once('message', resolve)
        setTimeout(resolve, 1000)
      }) * 1000
    }
    let muptime = clockString(_muptime)
    let uptime = clockString(_uptime)
    let totalreg = Object.keys(global.db.data.users).length
    let rtotalreg = Object.values(global.db.data.users).filter(user => user.registered == true).length
    let help = Object.values(global.plugins).filter(plugin => !plugin.disabled).map(plugin => {
      return {
        help: Array.isArray(plugin.tags) ? plugin.help : [plugin.help],
        tags: Array.isArray(plugin.tags) ? plugin.tags : [plugin.tags],
        prefix: 'customPrefix' in plugin,
        diamond: plugin.diamond,
        premium: plugin.premium,
        enabled: !plugin.disabled,
      }
    })
    if (teks == '404') {
      return conn.sendImgList(
  m.chat,
  "https://telegra.ph/file/9708607bb62a9b709c200.jpg",
  "> ✧────··[ Панель приборов ]··────✧",
  "",
  `
╭──═[ *информация о пользователе* ]═──⋆
⬡│▸ Diamond ➠ limit & ⓓ
⬡│▸ Premium ➠ Ⓟ
│╭───────────────···
┴│▸ *Имя:* _${name}_
⬡│▸ *уровень:* _${level}_
⬡│▸ *предел:* _${diamond}_
⬡│▸ *роль:* _${role}_
⬡│▸ *дата:* _${date}_
⬡│▸ *время безотказной работы:* _${muptime}_
┬│▸ *общее количество пользователей :* _${rtotalreg} - ${totalreg}_
│╰────────────────···
╰───────═┅═───────
> © судно`,
  "Одиночный_выбор",
  "Выберите один из списка",
  [

      ["Main Menu |🧷|", "[📮] Отображает главное меню", "© судно", ".? main"],

      ["Menu 01 |🧾|", "[📮] Отображает все меню бота", "© судно", ".? all"],

      ["Menu 02 |✨|", "[📮] Показывает все популярные меню", "© судно", ".? xyz"],

      ["Menu 03 |🧑‍💻|", "[📮] Показаны все популярные AI", "© судно", ".? ai"],

      ["Menu 04 |🤖|", "[📮] Показаны все боты (Sub-Bot)", "© судно", ".? jadibot"],

      ["Menu 05 |🎮|", "[📮] Отображает все меню игры", "© судно", ".? game"],

      ["Menu 06 |📝|", "[📮] Отображает меню регистрацииr", "© судно", ".? rg"],

      ["Menu 07 |💟|", "[📮] Отображает все меню стикеров", "© судно", ".? sticker"],

      ["Menu 08 |🏞️|", "[📮] Отображает все меню изображения", "© судно", ".? img"],

      ["Menu 09 |🖌️|", "[📮] Отображает все меню создания", "© судно", ".? maker"],

      ["Menu 10 |🔐|", "[📮] Показ всего Премиум-меню", "© судно", ".? prem"],

      ["Menu 11 |🪪|", "[📮] Отображает всю группу меню", "© судно", ".? group"],

      ["Menu 12 |🔮|", "[📮] Отображает все аниме-меню.", "© судно", ".? nime"],

      ["Menu 13 |📥|", "[📮] Отображает все меню загрузчика", "© судно", ".? dl"],

      ["Menu 14 |🔨|", "[📮] Отображает меню инструментов", "© судно", ".? tools"],

      ["Menu 15 |🎉|", "[📮] Отображает все меню развлечений", "© судно", ".? fun"],

      ["Menu 16 |🔞|", "[📮] Показывает все меню нсфв", "© судно", ".? nsfw"],

      ["Menu 17 |👑|", "[📮] Отображает специальное меню владельца", "© судно", ".? owner"]

  ])

    }
    

    /*for (let plugin of help)
      if (plugin && 'tags' in plugin)
        for (let tag of plugin.tags)
          if (!(tag in tags) && tag) tags[tag] = tag*/
    let groups = {}
    for (let tag in tags) {
      groups[tag] = []
      for (let plugin of help)
        if (plugin.tags && plugin.tags.includes(tag))
          if (plugin.help) groups[tag].push(plugin)
      // for (let tag of plugin.tags)
      //   if (!(tag in tags)) tags[tag] = tag
    }
    conn.menu = conn.menu ? conn.menu : {}
    let before = conn.menu && conn.menu.before ? conn.menu.before : defaultMenu.before
    let header = conn.menu && conn.menu.header ? conn.menu.header : defaultMenu.header
    let body = conn.menu && conn.menu.body ? conn.menu.body : defaultMenu.body
    let footer = conn.menu && conn.menu.footer ? conn.menu.footer : defaultMenu.footer
    let after = conn.menu && conn.menu.after ? conn.menu.after : (conn.user.jid == conn.user.jid ? '' : `⭐ Powered by судно https://wa.me/${conn.user.jid.split`@`[0]}`) + defaultMenu.after
    let _text = [
      before,
      ...Object.keys(tags).map(tag => {
        return header.replace(/%category/g, tags[tag]) + '\n' + [
          ...help.filter(menu => menu.tags && menu.tags.includes(tag) && menu.help).map(menu => {
            return menu.help.map(help => {
              return body.replace(/%cmd/g, menu.prefix ? help : '%p' + help)
                .replace(/%isdiamond/g, menu.diamond ? '(ⓓ)' : '')
                .replace(/%isPremium/g, menu.premium ? '(Ⓟ)' : '')
                .trim()
            }).join('\n')
          }),
          footer
        ].join('\n')
      }),
      after
    ].join('\n')
    let text = typeof conn.menu == 'string' ? conn.menu : typeof conn.menu == 'object' ? _text : ''
    let replace = {
      '%': '%',
      p: _p, uptime, muptime,
      me: conn.getName(conn.user.jid),
      sbot: (conn.user.jid == global.conn.user.jid ? '' : `\n▢ ✨ *Sub-Bot:*\nwa.me/${global.conn.user.jid.split`@`[0]}`), 
      npmname: _package.name,
      npmdesc: _package.description,
      version: _package.version,
      exp: exp - min,
      maxexp: xp,
      totalexp: exp,
      xp4levelup: max - exp,
      github: _package.homepage ? _package.homepage.url || _package.homepage : '[unknown github url]',
      level, diamond, name, weton, week, date, dateIslamic, time, totalreg, rtotalreg, role,
      readmore: readMore
    }
    text = text.replace(new RegExp(`%(${Object.keys(replace).sort((a, b) => b.length - a.length).join`|`})`, 'g'), (_, name) => '' + replace[name])
    
    let pp = './src/fg_logo.jpg'

    /*conn.sendButton(m.chat, text.trim(), `▢ DyLux  ┃ ᴮᴼᵀ\n${mssg.ig}`, pp, [
      ['ꨄ︎ Apoyar', `${_p}donate`],
      ['⏍ Info', `${_p}botinfo`],
      ['⌬ Grupos', `${_p}gpdylux`]
    ], m, rpl)*/
    /*conn.sendMessage(m.chat, {
text: text,
contextInfo: {
externalAdReply: {
title: NSnama,
body: "",
thumbnailUrl: NSthumb,
sourceUrl: NSgc,
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})*/
  /*conn.sendImgButton(
    m.chat,
    "https://telegra.ph/file/90f8e1932cb2e15d3ee9e.jpg",
    "✧───···[ Dashboard ]···────✧",
    "",
    `
${text.trim()}
© судно`,
    [
        ["Owner 🤴🏻", ".owner"], 
        ["Info Bot 🤖", ".info"],
        ["Cek Ping ⚡", ".ping"]
    ]
)*/
    const user = {jid: 'contoh@whatsapp.net'};   conn.sendMessage(m.chat, {
    text: text, 
      contextInfo: {
      externalAdReply: {
      title: "судно",
      body: "Don't Spamming",
      thumbnailUrl: `https://telegra.ph/file/9708607bb62a9b709c200.jpg`,
      sourceUrl: `https://hoshiyuki-api.my.id`,
      mediaType: 1,
      renderLargerThumbnail: true, 
        },
        forwardingScore: 10,
        isForwarded: true,
        mentionedJid: [m.sender],
        businessMessageForwardInfo: {
            businessOwnerJid: conn.user.jid
        },
        forwardedNewsletterMessageInfo: {
            newsletterJid: 'hoshiyuki@newsletter',
            serverMessageId: null,
            newsletterName: 'WhatsApp'
        }
    }
}, { quoted: { key: { participant: '0@s.whatsapp.net', remoteJid: "0@s.whatsapp.net" },  message: { conversation: 'судно Проверено WhatsApp ✓' }}});
    
  } catch (e) {
    conn.reply(m.chat, '❎ Извините, в меню ошибка', m)
    throw e
  }
}
//handler.help = ['help']
//handler.tags = ['main']
handler.command = ['menu', '?', 'help', 'allmenu'] 
handler.rowner = false
handler.register = false

export default handler

const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)

function clockString(ms) {
  let d = isNaN(ms) ? '--' : Math.floor(ms / 86400000)
  let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000) % 24
  let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
  let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
  return [d, 'd ', h, 'h ', m, 'm '].map(v => v.toString().padStart(2, 0)).join('')
}