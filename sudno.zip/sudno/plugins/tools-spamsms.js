import fetch from 'node-fetch';

let handler = async (m, { text, usedPrefix, command }) => {
       let [ nomor, jumlah ] = text.split(`|`)
       if (!nomor || !jumlah) throw `Masukkan Command .peler 628xxxx|5`;
           nomor = no(nomor)
       if (isNaN(nomor)) {nomor = nomor.split("@")[0] } else { nomor = nomor }
       if (jumlah >= 30) throw `max 30, karena yang punya restapi belum beli hostingan bagus😂`

try { 
       const response = await(await fetch(`https://hoshiyuki-api.my.id/api/spam-sms?nomor=${nomor}&jumlah=${jumlah}&apikey=Hoshiyuki`)).json();
    
       m.reply(`${response.message}`);
   } catch (error) { throw "Maaf, sepertinya sedang terjadi kesalahan teknis"; }
   
};

handler.help = ['spamsms'];
handler.tags = ['premium'];
handler.command = /^(spamsms)$/i;
handler.premium = true

export default handler;

function no(number){
    return number.replace(/\s/g,'').replace(/([@+-])/g,'')
  }