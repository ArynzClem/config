import fetch from 'node-fetch';
let { proto, generateWAMessageFromContent, generateWAMessageContent, prepareWAMessageMedia } = (await import('@whiskeysockets/baileys')).default

let handler = async (m, { conn, text, command }) => {
    if (!text) throw `❌ Penggunaan: .pinterest Naruto`;

    const res = await (await fetch(`https://api.betabotz.eu.org/api/search/pinterest?text1=${text}&apikey=Hoshiyuki`)).json();
    const url1 = `${res.result[0]}`;
    const url2 = `${res.result[1]}`;
    const url3 = `${res.result[2]}`;
    const url4 = `${res.result[3]}`;
    const url5 = `${res.result[4]}`;
    
    async function image(url1, url2, url3, url4, url5) {
        const { imageMessage } = await generateWAMessageContent({
            image: {
                url1, url2, url3, url4, url5
            }
        }, {
            upload: conn.waUploadToServer
        });
        return imageMessage;
    }

    let msg = generateWAMessageFromContent(
        m.chat,
        {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        body: { text: `Berikut adalah 5 Result dari ${text}:` },
                        carouselMessage: {
                            cards: [
                                {
                                    header: {
                                        ...(await prepareWAMessageMedia({ image: { url: url1 } }, { upload: conn.waUploadToServer })),
                                        hasMediaAttachment: true,
                                    },
                                    body: { text: "Image 1/5" },
                                    nativeFlowMessage: {
                                        buttons: [
                                            {
                                                name: "cta_url",
                                                buttonParamsJson: '{"display_text":"CLICK HERE","url": "https://chat.whatsapp.com/L8GDt49JfK77N52pQLp7h3","webview_presentation":null}',
                                            },
                                        ],
                                    },
                                },
                                {
                                    header: {
                                        ...(await prepareWAMessageMedia({ image: { url: url2 } }, { upload: conn.waUploadToServer })),
                                        hasMediaAttachment: true,
                                    },
                                    body: { text: "Image 2/5" },
                                    nativeFlowMessage: {
                                        buttons: [
                                            {
                                                name: "cta_url",
                                                buttonParamsJson: '{"display_text":"CLICK HERE","url":"https://chat.whatsapp.com/L8GDt49JfK77N52pQLp7h3","webview_presentation":null}',
                                            },
                                        ],
                                    },
                                },
                                {
                                    header: {
                                        ...(await prepareWAMessageMedia({ image: { url: url3 } }, { upload: conn.waUploadToServer })),
                                        hasMediaAttachment: true,
                                    },
                                    body: { text: "Image 3/5" },
                                    nativeFlowMessage: {
                                        buttons: [
                                            {
                                                name: "cta_url",
                                                buttonParamsJson: '{"display_text":"CLICK HERE","url":"https://chat.whatsapp.com/L8GDt49JfK77N52pQLp7h3","webview_presentation":null}',
                                            },
                                        ],
                                    },
                                },
                                {
                                    header: {
                                        ...(await prepareWAMessageMedia({ image: { url: url4 } }, { upload: conn.waUploadToServer })),
                                        hasMediaAttachment: true,
                                    },
                                    body: { text: "Image 4/5" },
                                    nativeFlowMessage: {
                                        buttons: [
                                            {
                                                name: "cta_url",
                                                buttonParamsJson: '{"display_text":"CLICK HERE","url":"https://chat.whatsapp.com/L8GDt49JfK77N52pQLp7h3","webview_presentation":null}',
                                            },
                                        ],
                                    },
                                },
                                {
                                    header: {
                                        ...(await prepareWAMessageMedia({ image: { url: url5 } }, { upload: conn.waUploadToServer })),
                                        hasMediaAttachment: true,
                                    },
                                    body: { text: "Image 5/5" },
                                    nativeFlowMessage: {
                                        buttons: [
                                            {
                                                name: "cta_url",
                                                buttonParamsJson: '{"display_text":"CLICK HERE","url":"https://chat.whatsapp.com/L8GDt49JfK77N52pQLp7h3","webview_presentation":null}',
                                            },
                                        ],
                                    },
                                },
                            ],
                            messageVersion: 1,
                        },
                    },
                },
            },
        },
        {}
    );

    await conn.relayMessage(msg.key.remoteJid, msg.message, {
        messageId: msg.key.id,
    });
};

handler.help = ['pinterest'];
handler.tags = ['img'];
handler.command = /^(pin(t|terest)?)$/i;
handler.diamond = 5;

export default handler;