import fetch from 'node-fetch';

let handler = async (m, { conn, usedPrefix, command, text }) => {
    if (!text) return m.reply(`• *Contoh :* ${usedPrefix}${command} 10000`);
    if (text < 10000) return m.reply('```Minimal Deposit Rp 10.000, 20000, 25000, 30000, 35000, 40000, 45000, 55000, 60000, 65000, 70000, 75000, 80000, 85000, 90000, 95000, 100000```');

    let user = global.db.data.users[m.sender];
    let kemii = await (await fetch(`https://api.neoxr.eu/api/topup-dana?number=087708773367&amount=${text}`)).json();
    let buffer = Buffer.from(kemii.data.qr_image, "base64");
    let teks = 'Info Pembayaran\n\n';
    teks += 'Pembayaran Sebelum : ' + `${kemii.data.expired_at}\n\n`;
    teks += '• ID Pembayaran : ' + `${kemii.data.id}\n`;
    teks += '• Total Pembayaran : ' + `${kemii.data.price_format}\n\n`;
    teks += 'Note : \n';
    teks += '• Kode QR hanya valid untuk 1 kali transfer.\n';
    teks += '• Setelah pembayaran, harap tunggu 30 detik.\n';
    teks += '• Jika pembayaran berhasil, status akan diperbarui otomatis.\n';
    teks += '• Untuk bantuan lebih lanjut, hubungi *.owner*\n\n';
    teks += 'Hoshiyuki-Bot MD || WhatsApp Asisten';
    let { key } = await conn.sendFile(m.chat, buffer, 'deposit.jpg', teks, m);

    // Periksa status pembayaran secara berkala hingga berhasil
    let intervalId = setInterval(async () => {
        let topup = await (await fetch(`https://api.neoxr.eu/api/topup-check?id=${kemii.data.id}&code=${kemii.data.code}`)).json();
        if (topup.data.status === "SUCCEEDED") {
            clearInterval(intervalId); // Hentikan pengecekan berulang
            user.saldo += text;
            user.prem = true;
            let now = new Date() * 1;
            let days = 30;
            let expirationTime = now + (days * 24 * 60 * 60 * 1000);
            user.premiumTime = expirationTime;
            let ss = '```Pembayaran sukses, anda menerima saldo sejumlah : ```' + `Rp. ${toRupiah(text)}` + '\nPremium: True\nTime: 30 day';
            await conn.reply(m.chat, ss, key);
        }
    }, 10000); // Periksa setiap 10 detik
};

handler.help = ['deposit *<jumlah>*'];
handler.tags = ['main'];
handler.command = /^(deposit|depo)$/i;
handler.register = true;
export default handler;

function toRupiah(angka) {
    let saldo = '';
    let angkarev = angka.toString().split('').reverse().join('');
    for (let i = 0; i < angkarev.length; i++)
        if (i % 3 == 0) saldo += angkarev.substr(i, 3) + '.';
    return '' + saldo.split('', saldo.length - 1).reverse().join('');
}