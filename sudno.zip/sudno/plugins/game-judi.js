// Thanks To [HirooSy]
// Thanks To [RizalDev]
// Recode By YukiSmall

let handler = async (m, { conn, args, usedPrefix }) => {
    let user = global.db.data.users[m.sender]
    if (!args[0]) return conn.reply(m.chat, `${usedPrefix}judi <jumlah>\nContoh: ${usedPrefix}judi 1000`, m)
    
    if (!(/^(y|yes|n|no)$/i.test(args[1])) || !args[1]) {
        return conn.sendButton(m.chat, "Apakah kamu yakin ingin memulai judi?", "Tekan Yes atau No", "© Hoshiyuki-Bot", [["Yes", `.judi ${args[0]}` + " y"], ["No", `.judi ${args[0]} ` + "n"]]);
    } else if (/n(o)?/.test(args[1])) {
        return conn.reply(m.chat, "Judi telah dibatalkan.", m)
    } else if (/y(es)?/.test(args[1])) { 
            let __waktutionskh = new Date() - (user.judiLast || 0)
            let _waktutionskh = 5000 - __waktutionskh
            let waktutionskh = clockString(_waktutionskh)
            if (new Date() - (user.judiLast || 0) > 5000) {
                user.judiLast = new Date() * 1
                let randomaku = `${Math.floor(Math.random() * 101)}`.trim()
                let randomkamu = `${Math.floor(Math.random() * 75)}`.trim() //hehe Biar Susah Menang :v
                let Aku = randomaku * 1
                let Kamu = randomkamu * 1
                let count = args && args[0] // Amount from arguments
                count = count ? /all/i.test(count) ? Math.floor(user.coin / all) : parseInt(count) : null
                if (count == null || isNaN(count) || count <= 0) throw "Masukkan jumlah yang valid"
                if (user.coin >= count * 1) {
                    user.coin -= count * 1
                    if (Aku > Kamu) {
                        conn.reply(m.chat, `aku roll:${Aku}\nKamu roll: ${Kamu}\n\nkamu *Kalah*, kamu kehilangan ${count} coin`.trim(), m)
                    } else if (Aku < Kamu) {
                        user.coin += count * 2
                        conn.reply(m.chat, `aku roll:${Aku}\nKamu roll: ${Kamu}\n\nkamu *Menang*, kamu Mendapatkan ${count * 2} coin`.trim(), m)
                    } else {
                        user.coin += count * 1
                        conn.reply(m.chat, `aku roll:${Aku}\nKamu roll: ${Kamu}\n\nkamu *Seri*, kamu Mendapatkan ${count * 1} coin`.trim(), m)
                    }
                } else conn.reply(m.chat, `Coin kamu tidak cukup untuk melakukan judi sebesar ${count} coin`.trim(), m)
            } else conn.reply(m.chat, `Kamu sudah judi, tidak bisa judi kembali..\nMohon tunggu ${waktutionskh} lagi untuk judi kembali `, m)
        }
    
}
handler.help = ['judi <jumlah>']
handler.tags = ['game']
handler.command = /^(judi)$/i

export default handler

function pickRandom(list) {
    return list[Math.floor(Math.random() * list.length)]
}

function clockString(ms) {
    let h = Math.floor(ms / 3600000)
    let m = Math.floor(ms / 60000) % 60
    let s = Math.floor(ms / 1000) % 60
    console.log({ ms, h, m, s })
    return [h, m, s].map(v => v.toString().padStart(2, 0)).join(':')
}