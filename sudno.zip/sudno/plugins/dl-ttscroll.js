import fetch from 'node-fetch';
const { generateWAMessageFromContent, generateWAMessageContent } = (await import('@whiskeysockets/baileys')).default;

let handler = async (m, { conn, text }) => {
    if (!text) throw `❌ Penggunaan: .ttscroll Kobo Kanaeru`;
    m.react('🕖')
    let json = await fetch(`https://skizo.tech/api/tiktok-search?apikey=Hoshiyuki&keywords=${text}`);
    let jsonData = await json.json(); // Convert response to JSON

    async function video(url) {
        const { videoMessage } = await generateWAMessageContent({
            video: {
                url
            }
        }, {
            upload: conn.waUploadToServer
        });
        return videoMessage;
    }

    let msg = generateWAMessageFromContent(
        m.chat,
        {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        body: {
                            text: `result from ${text}`
                        },
                        carouselMessage: {
                            cards: [
                                { header: { videoMessage: await video(jsonData[0].play), hasMediaAttachment: true }, body: { text: `[ T I K T O K - S C R O L L ]\n\n*Duration* : ${jsonData[0].duration}\n*Play* : ${jsonData[0].play_count}\n*Download* : ${jsonData[0].download_count}\n*Share* : ${jsonData[0].share_count}\n*Comment* : ${jsonData[0].comment_count}\n*Like* : ${jsonData[0].digg_count}\n\n` }, nativeFlowMessage: { buttons: [{ "name": "quick_reply", "buttonParamsJson": `{\"display_text\":\"NEXT VIDEO\",\"id\":\".ttscroll ${text}\"}` }] } },
                                { header: { videoMessage: await video(jsonData[1].play), hasMediaAttachment: true }, body: { text: `[ T I K T O K - S C R O L L ]\n\n*Duration* : ${jsonData[1].duration}\n*Play* : ${jsonData[1].play_count}\n*Download* : ${jsonData[1].download_count}\n*Share* : ${jsonData[1].share_count}\n*Comment* : ${jsonData[1].comment_count}\n*Like* : ${jsonData[1].digg_count}\n\n` }, nativeFlowMessage: { buttons: [{ "name": "quick_reply", "buttonParamsJson": `{\"display_text\":\"NEXT VIDEO\",\"id\":\".ttscroll ${text}\"}` }] } },
                                { header: { videoMessage: await video(jsonData[2].play), hasMediaAttachment: true }, body: { text: `[ T I K T O K - S C R O L L ]\n\n*Duration* : ${jsonData[2].duration}\n*Play* : ${jsonData[2].play_count}\n*Download* : ${jsonData[2].download_count}\n*Share* : ${jsonData[2].share_count}\n*Comment* : ${jsonData[2].comment_count}\n*Like* : ${jsonData[2].digg_count}\n\n` }, nativeFlowMessage: { buttons: [{ "name": "quick_reply", "buttonParamsJson": `{\"display_text\":\"NEXT VIDEO\",\"id\":\".ttscroll ${text}\"}` }] } }
                            ],
                            messageVersion: 1
                        }
                    }
                }
            }
        },
        {}
    );

    await conn.relayMessage(msg.key.remoteJid, msg.message, {
        messageId: msg.key.id,
    });
    m.react('✅', msg.key.id)
};

handler.help = ['ttscroll'];
handler.tags = ['dl'];
handler.command = /^(ttscroll|tiktokscroll)$/i;
handler.diamond = 5;

export default handler;