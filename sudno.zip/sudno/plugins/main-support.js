let handler = async (m, { conn }) => {
  
  m.reply(`
≡  *${NSnama}┃ SUPPORT*

> ◈ *Thx For Support All*
- \`NansOffc\`
- \`BetaBotz API\`
- \`Hiroosy\`
- \`AmmarBN\`
- \`Adrian OLXYZ\`
- \`XYZ TEAM\`

> ▢ *Join Grup Hoshiyuki*
- \`[Join Here](https://whatsapp.com/channel/0029VaWNXqF8fewpBpaCiQ1K)\`

> ≡ Donation For Bot
- \`[Donate Here](https://saweria.co/Hoshiyuki)\`
`);
}

handler.help = ['support'];
handler.tags = ['main'];
handler.command = ['grupos', 'groups', 'support'];

export default handler;