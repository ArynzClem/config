import fetch from "node-fetch";

const errorLog = `> *(;ŏ﹏ŏ) Ops! Something went wrong.*\n\n*Try :*\n- Check again your tiktok url.\n- report this error to owner.\n- mewing.`

let handler = async (m, { conn, args, command}) => {
  
if (command == "tiktok" || command == "tt") {
     if (!args[0]) throw '> Where The Url?'
        let link = isCorrectLink(args[0]);
     if (link === null) throw '> Invalid Url!'

await m.react("⬇️")
try {

let result = await (await fetch(`https://tikwm.com/api/?url=` + link)).json()
if (result.data.images) { 
        await m.reply(`> • *\`Author:\`* ${result.data.author.nickname} ( @ ${result.data.author.unique_id} )\n> • *\`Desciption:\`*\n> ${!result.data.title ? "‎" : result.data.title == '' ? "‎" : result.data.title}`)
        for (let i = 0; i < result.data.images.length; i++) {
		        conn.sendFile(m.chat, result.data.images[i], "tiktok.png", null, null)
       }
       m.react("✅")
	} else {
     await conn.sendFile(m.chat, result.data.play, "tiktok.mp4", `> • *\`Author:\`* ${result.data.author.nickname} ( @ ${result.data.author.unique_id} )\n> • *\`Desciption:\`*\n> ${!result.data.title ? "‎" : result.data.title == '' ? "‎" : result.data.title}`, m)
     m.react("✅")
    }
   
      } catch (e) {
      throw errorLog
      }
  }
  
  
if (command == "tiktokaudio" || command == "ttaudio") {
     if (!args[0]) throw '> Where The Url?'
         let link = isCorrectLink(args[0]);
     if (link === null) throw '> Invalid Url!'
         let chat = global.db.data.chats[m.chat]
     await m.react("⬇️")
     
     try {
     let result = await (await fetch(`https://tikwm.com/api/?url=` + link)).json()
     await conn.sendFile(m.chat, result.data.music, "tiktok.mp" + 3, null, m, false, { mimetype: 'audio/mpeg', asDocument: chat.useDocument, 
                               contextInfo:{ 
                               externalAdReply:{
                                  mediaUrl:'',
                                  mediaType:2,
                                  title:result.data.music_info.title,                                     
                                  body: `𝗔𝘂𝘁𝗵𝗼𝗿: ${result.data.music_info.author}`,
                                  thumbnail: await (await fetch(result.data.music_info.cover)).buffer(),
                                  sourceUrl: ''}}})
     } catch(e) {
          throw errorLog
       }
   }
  
}
handler.help = ['tiktok', 'tiktokaudio'].map(v => v + ' <url>')
handler.tags = ['dl']
handler.dym = ['tiktok', 'tiktokaudio']
handler.command = /^(tt|tiktok)(audio)?$/i
handler.diamond = true

export default handler

function isCorrectLink(text) {
    let pattern = /https?:\/\/\S+/gi;
    let links = text.match(pattern);
    return links;
};