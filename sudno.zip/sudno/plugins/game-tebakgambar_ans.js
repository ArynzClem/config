import similarity from 'similarity'

let threshold = 0.72

let handler = m => m

handler.before = async function (m) {
    let id = m.chat
    if (!m.quoted || !m.quoted.fromMe || !m.quoted.isBaileys || !/Ketik.*htg/i.test(m.quoted.text)) return true
    this.tebakgambar = this.tebakgambar ? this.tebakgambar : {}
    if (!(id in this.tebakgambar)) return m.reply('Soal itu telah berakhir')
    if (m.quoted.id == this.tebakgambar[id][0].id) {
        let json = JSON.parse(JSON.stringify(this.tebakgambar[id][1]))
        if (m.text.toLowerCase() == json.result.jawaban.toLowerCase().trim()) {
            global.db.data.users[m.sender].exp += this.tebakgambar[id][2]
            global.db.data.users[m.sender].coin += this.tebakgambar[id][3]
            global.db.data.users[m.sender].diamond += this.tebakgambar[id][4]
            m.reply(`*Benar!*\n+${this.tebakgambar[id][2]} XP\n+${this.tebakgambar[id][3]} Coin\n+${this.tebakgambar[id][4]} Diamond`)
            clearTimeout(this.tebakgambar[id][5])
            delete this.tebakgambar[id]
        } else if (similarity(m.text.toLowerCase(), json.result.jawaban.toLowerCase().trim()) >= threshold) m.reply(`*Dikit Lagi!*`)
        else m.reply(`*Salah!*`)
    }
    return true
}

handler.exp = 0

export default handler