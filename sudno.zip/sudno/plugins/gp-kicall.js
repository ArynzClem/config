import { MessageType } from '@whiskeysockets/baileys'

let handler = async (m, { conn }) => {
    const participants = m.chat.groupMetadata.participants
    const kickedUsers = []
    for (let participant of participants) {
        if (participant.jid !== conn.user.jid && !participant.isAdmin && !participant.isSuperAdmin) {
            await conn.groupRemove(m.chat, [participant.jid])
            kickedUsers.push(participant.jid)
            await delay(1 * 1000) // Delay untuk menghindari pemblokiran sementara oleh WhatsApp
        }
    }
    m.reply(`Sukses mengkick ${kickedUsers.length} anggota.`, null, { mentions: kickedUsers, contextInfo: { mentionedJid: kickedUsers } })
}

handler.help = ['kickall']
handler.tags = ['admin']
handler.command = /^(okickall)$/i

handler.group = true
handler.admin = true
handler.botAdmin = true

export default handler

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms))