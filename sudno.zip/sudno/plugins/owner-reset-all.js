let handler = async (m, { conn }) => {
    for (let jid in global.db.data.users) {
        let userData = global.db.data.users[jid]
        if (!userData.prem) { // Jika bukan pengguna premium
            userData.diamond = 10
            userData.exp = 0
            userData.coin = 10000
            userData.bank = 0
            global.db.data.users[jid] = userData
        }
    }
    
    conn.reply(m.chat, `*❏ Reset Semua Pengguna (Kecuali Premium)*\n\n✅ Telah dilakukan reset pada semua pengguna non-premium di *DATABASE*`, m)
}
handler.help = ['reset-all']
handler.tags = ['owner']
handler.command = ['reset-all']
handler.rowner = true

export default handler