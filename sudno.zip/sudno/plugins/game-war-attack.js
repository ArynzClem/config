let handler = async (m, { conn, args }) => {
  if (!conn.war) conn.war = {}
  if (!conn.war2) conn.war2 = {}

  if (!(m.chat in conn.war)) return m.reply('*Tidak ada permainan yang sedang berlangsung di room ini*')
  if (!conn.war2[m.chat].war) return m.reply('*Game belum dimulai*')

  let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : args[0] ? args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : ''
  if (!who) return m.reply('*Tag player yang ingin di serang!*')
  if (who == m.sender) return m.reply('*Tidak bisa menyerang diri sendiri*')

  let player = conn.war[m.chat].find(v => v.user == m.sender)
  if (!player) return m.reply('*Kamu tidak terdaftar di room ini*')
  if (player.dead) return m.reply('*Kamu sudah mati, tidak bisa menyerang!*')

  let enemy = conn.war[m.chat].find(v => v.user == who)
  if (!enemy) return m.reply('*Player tidak terdaftar di room ini*')
  if (enemy.dead) return m.reply('*Player yang ingin diserang sudah mati*')

  if (conn.war2[m.chat].turn != conn.war[m.chat].indexOf(player)) return m.reply('*Sekarang bukan giliranmu untuk menyerang!*')

  let damage = Math.floor(Math.random() * 10) + 1
  enemy.hp -= damage

  let text = `*${player.user.split('@')[0]} menyerang ${enemy.user.split('@')[0]} dan memberikan ${damage} damage!*\n\n`
  if (enemy.hp <= 0) {
    enemy.dead = true
    text += `*${enemy.user.split('@')[0]} telah mati!*`
  } else {
    text += `*HP ${enemy.user.split('@')[0]} sekarang ${enemy.hp}*`
  }

  let teamA = conn.war[m.chat].slice(0, 5).filter(v => !v.dead).length
  let teamB = conn.war[m.chat].slice(5).filter(v => !v.dead).length

  if (teamA == 0 || teamB == 0) {
    let winner = teamA > 0 ? 'Team A' : 'Team B'
    text += `\n\n*${winner} memenangkan permainan!*`
    conn.war2[m.chat].war = false
    delete conn.war[m.chat]
    delete conn.war2[m.chat]
  } else {
    conn.war2[m.chat].turn = (conn.war2[m.chat].turn + 1) % 10
  }

  return m.reply(text, m, { contextInfo: { mentionedJid: [player.user, enemy.user] } })
}

handler.help = ['attack']
handler.tags = ['game']
handler.command = /^attack$/i

export default handler