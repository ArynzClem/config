import fetch from 'node-fetch'

let handler = async (m, { conn }) => {
    let waifu = (await (await fetch("https://raw.githubusercontent.com/AmmarrBN/dbbot/main/nsfw/nsfwml.json")).json()).getRandom()
    conn.sendImgButton(m.chat, waifu, '', "Hentai Mobil Legenda", '', ["Gacha", ".nsfwml"])
    
}

handler.command = /^(nsfwml)$/i
handler.tags = ['ansfw']
handler.help = ['nsfwml']
handler.group = false
handler.register = true
handler.diamond = true
export default handler
function pickRandom(list) {
    return list[Math.floor(Math.random() * list.length)]
}