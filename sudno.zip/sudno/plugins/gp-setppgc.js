import fs from 'fs'
import Jimp from 'jimp'
import uploadImage from "../lib/uploadImage.js"
let handler = async (m, { conn, isROwner, args, isOwner, command, isAdmin, isbotAdmin, usedPrefix }) => {
 
//==========[ DETECT ]==========
let q = m.quoted ? m.quoted : m
let mime = (q.msg || q).mimetype || ''
if (!mime) throw 'reply / caption gambar !'
let isMedia = /image\/(png|jpe?g)/.test(mime)
if (!isMedia) throw `Mime ${mime} tidak didukung`


var media = await q.download()
let botNumber = await conn.user.jid
let gc = m.chat
var { img } = await generateProfilePicture(media)

let link = await (isMedia ? uploadImage : uploadImage)(media)
var source = await Jimp.read(await link)
 
if (/setppbot/.test(command)) {
                if (!isOwner) {
            	global.dfail('owner', m,conn)
                throw false
                }
            await conn.query({
            tag: 'iq',
            attrs: {
            to: botNumber,
            type:'set',
            xmlns: 'w:profile:picture'
            },
            content: [
            {
            tag: 'picture',
            attrs: { type: 'image' },
            content: img
            }
            ]
            })
            conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } })
}


if (/setpp(gc|group)/.test(command)) {
                  if (!m.isGroup) return global.dfail('group',m,conn)
                  if (m.isGroup) {
                  if (!isAdmin) return global.dfail('admin', m,conn)
                }
                
                await conn.query({
            tag: 'iq',
            attrs: {
            to: gc,
            type:'set',
            xmlns: 'w:profile:picture'
            },
            content: [
            {
            tag: 'picture',
            attrs: { type: 'image' },
            content: img
            }
            ]
            })
            await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } })
}

}
handler.dym = ["setppbot", " setppgc", "setppgroup"]
handler.help = ['setppbot', 'setppgc'].map(v => v + ' (reply|caption)')
handler.tags = ['gp']
handler.command = /^(setpp(bot|gc|group))$/i

export default handler

async function generateProfilePicture(buffer) {
	const jimp_1 = await Jimp.read(buffer);
	const resz = jimp_1.getWidth() > jimp_1.getHeight() ? jimp_1.resize(550, Jimp.AUTO) : jimp_1.resize(Jimp.AUTO, 650)
	const jimp_2 = await Jimp.read(await resz.getBufferAsync(Jimp.MIME_JPEG));
	return {
	  img: await resz.getBufferAsync(Jimp.MIME_JPEG)
	}
}