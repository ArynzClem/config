import fetch from 'node-fetch';
const { proto, generateWAMessageFromContent, generateWAMessageContent } = (await import('@whiskeysockets/baileys')).default;

let handler = async (m, { conn, text }) => {
    if (!text) throw `❌ Penggunaan: .ttscroll Kobo Kanaeru`;

    const res = await fetch(`https://api.betabotz.eu.org/api/search/tiktoks?query=${text}&apikey=Hoshiyuki`);
    const json = await res.json();

    if (!json.status) throw "Failed to fetch TikTok data. Please try again later.";

    const data = json.result.data;
    const pickRandom = (arr) => arr[Math.floor(Math.random() * arr.length)];

    async function video(url) {
        const { videoMessage } = await generateWAMessageContent({
            video: { url }
        }, {
            upload: conn.waUploadToServer
        });
        return videoMessage;
    }

    const [json1, json2, json3, json4, json5] = [
        pickRandom([json[0], json[1], json[3]]),
        pickRandom([json[5], json[6], json[7]]),
        pickRandom([json[9], json[2]]),
        pickRandom([json[8], json[5], json[6], json[7]]),
        pickRandom([json[4], json[9], json[1]])
    ];

    let msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: {
                        text: `result from ${text}`
                    },
                    carouselMessage: {
                        cards: [
                            { 
                                header: { 
                                    videoMessage: await video(json1.play), 
                                    hasMediaAttachment: true 
                                }, 
                                body: { 
                                    text: `[ T I K T O K - S C R O L L ]\n\n*Duration* : ${json1.duration}\n*Play* : ${json1.play_count}\n*Download* : ${json1.download_count}\n*Share* : ${json1.share_count}\n*Comment* : ${json1.comment_count}\n*Like* : ${json1.digg_count}\n\n` 
                                }, 
                                nativeFlowMessage: { 
                                    buttons: [{ 
                                        "name": "quick_reply", 
                                        "buttonParamsJson": `{\"display_text\":\"NEXT VIDEO\",\"id\":\".tiktokscroll ${text}\"}` 
                                    }] 
                                } 
                            },
                            { 
                                header: { 
                                    videoMessage: await video(json2.play), 
                                    hasMediaAttachment: true 
                                }, 
                                body: { 
                                    text: `[ T I K T O K - S C R O L L ]\n\n*Duration* : ${json2.duration}\n*Play* : ${json2.play_count}\n*Download* : ${json2.download_count}\n*Share* : ${json2.share_count}\n*Comment* : ${json2.comment_count}\n*Like* : ${json2.digg_count}\n\n` 
                                }, 
                                nativeFlowMessage: { 
                                    buttons: [{ 
                                        "name": "quick_reply", 
                                        "buttonParamsJson": `{\"display_text\":\"NEXT VIDEO\",\"id\":\".tiktokscroll ${text}\"}` 
                                    }] 
                                } 
                            },
                            { 
                                header: { 
                                    videoMessage: await video(json3.play), 
                                    hasMediaAttachment: true 
                                }, 
                                body: { 
                                    text: `[ T I K T O K - S C R O L L ]\n\n*Duration* : ${json3.duration}\n*Play* : ${json3.play_count}\n*Download* : ${json3.download_count}\n*Share* : ${json3.share_count}\n*Comment* : ${json3.comment_count}\n*Like* : ${json3.digg_count}\n\n` 
                                }, 
                                nativeFlowMessage: { 
                                    buttons: [{ 
                                        "name": "quick_reply", 
                                        "buttonParamsJson": `{\"display_text\":\"NEXT VIDEO\",\"id\":\".tiktokscroll ${text}\"}` 
                                    }] 
                                } 
                            },
                            { 
                                header: { 
                                    videoMessage: await video(json4.play), 
                                    hasMediaAttachment: true 
                                }, 
                                body: { 
                                    text: `[ T I K T O K - S C R O L L ]\n\n*Duration* : ${json4.duration}\n*Play* : ${json4.play_count}\n*Download* : ${json4.download_count}\n*Share* : ${json4.share_count}\n*Comment* : ${json4.comment_count}\n*Like* : ${json4.digg_count}\n\n` 
                                }, 
                                nativeFlowMessage: { 
                                    buttons: [{ 
                                        "name": "quick_reply", 
                                        "buttonParamsJson": `{\"display_text\":\"NEXT VIDEO\",\"id\":\".tiktokscroll ${text}\"}` 
                                    }] 
                                } 
                            },
                            { 
                                header: { 
                                    videoMessage: await video(json5.play), 
                                    hasMediaAttachment: true 
                                }, 
                                body: { 
                                    text: `[ T I K T O K - S C R O L L ]\n\n*Duration* : ${json5.duration}\n*Play* : ${json5.play_count}\n*Download* : ${json5.download_count}\n*Share* : ${json5.share_count}\n*Comment* : ${json5.comment_count}\n*Like* : ${json5.digg_count}\n\n` 
                                }, 
                                nativeFlowMessage: { 
                                    buttons: [{ 
                                        "name": "quick_reply", 
                                        "buttonParamsJson": `{\"display_text\":\"NEXT VIDEO\",\"id\":\".tiktokscroll ${text}\"}` 
                                    }] 
                                } 
                            }
                        ],
                        messageVersion: 1
                    }
                }
            }
        }
    });

    await conn.relayMessage(msg.key.remoteJid, msg.message, {
        messageId: msg.key.id,
    });
};

handler.help = ['ttscroll'];
handler.tags = ['dl'];
handler.command = /^(tt|tiktok(scroll)?)$/i;
handler.diamond = 5;

export default handler;