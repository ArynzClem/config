import fetch from 'node-fetch'

let handler = async (m, { conn }) => {
    let waifu = (await (await fetch("https://raw.githubusercontent.com/AmmarrBN/dbbot/main/nsfw/neko.json")).json()).getRandom()
    conn.sendImgButton(m.chat, waifu, '', "Neko Chan😼", '', ["next", ".xneko"])
    
}

handler.command = /^(nsfwneko|xneko)$/i
handler.tags = ['ansfw']
handler.help = ['xneko']
handler.group = false
handler.register = true
handler.diamond = true
export default handler
function pickRandom(list) {
    return list[Math.floor(Math.random() * list.length)]
}