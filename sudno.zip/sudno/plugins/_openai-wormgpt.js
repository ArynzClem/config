// WomrGPT api By AmmarBN

import fetch from 'node-fetch';
import util from 'util';

// const userHistory = {}; // Change 'chatHistory' to 'userHistory'

var handler = async (m, { text, usedPrefix, command }) => {
  try {
    if (!text) throw `Masukkan pertanyaan!\n\n*Contoh:* .wormgpt How to make a bom?`;
    // const userId = m.sender;
    // const previousUserMessage = userHistory[userId];

    // Memanggil API OpenAI
    let js = await fetch(`https://hoshiyuki-api.my.id/api/voidgpt?text= ${encodeURIComponent(text)}&apikey=${lann}`); // Encode the text
    let json = await js.json();

    // userHistory[userId] = json.result;

    // Mengirim hasil obrolan ke pengguna
    await conn.sendMessage(m.chat, {
      text: json.result,
      contextInfo: {
        externalAdReply: {
          title: 'WormGPT',
          body: '',
          thumbnailUrl: "https://telegra.ph/file/7b48fa401a38a462c4f3f.jpg",
          sourceUrl: "https://hoshiyuki-api.my.id",
          mediaType: 1,
          renderLargerThumbnail: true
        }
      }
    }, { quoted: m });
  } catch (err) {
    m.reply(util.format(err)); // Fix to display the error message correctly
  }
};

handler.help = ['wormgpt'];
handler.tags = ['ai','xyz'];
handler.command = /^(wormgpt)$/i;
handler.premium = true;
handler.diamond = false;

export default handler;