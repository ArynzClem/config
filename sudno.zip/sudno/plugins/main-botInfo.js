import fs from 'fs';
import path from 'path';
import os from 'os';
import { performance } from 'perf_hooks';
import { sizeFormatter } from 'human-readable';

let pref = globalThis.pref;

const __dirname = path.dirname(new URL(import.meta.url).pathname);

const handler = async (m, { conn, usedPrefix }) => { 
  const cpus = os.cpus().map(cpu => {
    cpu.total = Object.keys(cpu.times).reduce((last, type) => last + cpu.times[type], 0);
    return cpu;
  });

  const cpu = cpus.reduce((last, cpu, _, { length }) => {
    last.total += cpu.total;
    last.speed += cpu.speed / length;
    last.times.user += cpu.times.user;
    last.times.nice += cpu.times.nice;
    last.times.sys += cpu.times.sys;
    last.times.idle += cpu.times.idle;
    last.times.irq += cpu.times.irq;
    return last;
  }, {
    speed: 0,
    total: 0,
    times: {
      user: 0,
      nice: 0,
      sys: 0,
      idle: 0,
      irq: 0
    }
  });

  let pkg = JSON.parse(fs.readFileSync(path.join(__dirname, '../package.json')));
  let _uptime = process.uptime() * 1000;
  let uptime = clockString(_uptime);
  let totalreg = Object.keys(globalThis.db.data.users).length;
  let old = Math.round(performance.now());
  await m.reply('*[ ❗ ] Loading...*');
  let neww = Math.round(performance.now());
  let str = `
    *ℒ⃝👾 B O T  S T A T I S T I C*

    👩🏻‍💻 *Owner:* wa.me/6288229683561
    🧪 *Mode:* ${globalThis.opts['self'] ? 'Private' : 'Publik'}
    📊 *Versi:* ${pkg.version}
    💻 *Platform:* Unbuntu Linux
    🗃️ *Lib:* Baileys
    🏮 *Type:* NodeJs
    🧿 *Server:* ${os.hostname()}
    📢 *Report:* wa.me/6285600204672
    ⭕ *Prefix:* (# / ! .)
    🍃 *Speed:* ${neww - old} *ms*
    👥 *Total user:* ${totalreg} *user*
    ⏰ *Uptime:* ${uptime}


    *ℒ⃝📱P H O N E  S T A T I S T I C*

    *🛑 Ram:* ${format(os.totalmem() - os.freemem())} / ${format(os.totalmem())}
    *📈 MCC:* ${conn.user.phone ? conn.user.phone.mcc : 'Not Available'}
    *📉 MNC:* ${conn.user.phone ? conn.user.phone.mnc : 'Not Available'}
    *📊 OS Version:* ${os.platform()} ${conn.user.phone ? conn.user.phone.os_version : 'Not Available'}
    *📫 Merk Hp:* ${conn.user.phone ? conn.user.phone.device_manufacturer : 'Not Available'}
    *📮 Versi Hp:* ${conn.user.phone ? conn.user.phone.device_model : 'Not Available'}


    *ℒ⃝💻C O N N E C T  W I T H  M E*

    ⛎ *Api:* https://hoshiyuki-api.my.id
    ♈ *Youtube:* https://youtube.com/@AmmarExecuted?si=zzlpCU5mAo17QHFg
    ♉ *Github:* https://github.com/AmmarrBN
    ♊ *Insragram:* http://instagram.com/ammarbn27
    ♏ *Whatsapp:* -
  `.trim();
  conn.sendButton(
    m.chat, 
    "✧───···[ Dashboard ]···────✧",
    "",
    str,
    [["Owner 🤴🏻", ".owner"], ["Back Menu", ".menu"]]
  );
};

handler.help = ['info'];
handler.tags = ['main'];
handler.command = /^(info)$/i;
handler.fail = null;

export default handler;

let botol = globalThis.botwm;

const more = String.fromCharCode(8206);
const readMore = more.repeat(4001);

function clockString(ms) {
  let h = Math.floor(ms / 3600000);
  let m = Math.floor(ms / 60000) % 60;
  let s = Math.floor(ms / 1000) % 60;
  console.log({ms,h,m,s});
  return [h, m, s].map(v => v.toString().padStart(2, 0)).join(':');
}

function format(bytes) {
    const units = ["B", "KB", "MB", "GB", "TB"];
    let i = 0;
    while (bytes >= 1024 && i < 4) {
        bytes /= 1024;
        i++;
    }
    return `${bytes.toFixed(2)} ${units[i]}`;
}