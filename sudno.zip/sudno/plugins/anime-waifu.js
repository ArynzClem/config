import fetch from 'node-fetch'

let handler = async (m, { conn }) => {
    let waifu = (await (await fetch("https://raw.githubusercontent.com/AmmarrBN/dbbot/main/Anime/waifu.json")).json()).getRandom()
    conn.sendImgButton(m.chat, waifu, '', "Random Waifu", '', ["next", ".waifu"])
    
}

handler.command = /^(waifu)$/i
handler.tags = ['anime']
handler.help = ['waifu']
handler.group = false
handler.register = true
handler.diamond = true
export default handler
function pickRandom(list) {
    return list[Math.floor(Math.random() * list.length)]
}