import Replicate from "replicate"


let handler = async(m, { conn, usedPrefix, text, args, command }) => {
let chat = db.data.chats[m.chat]
	
if (!args[0]) throw `*example:*\n${usedPrefix + command} <model>
${usedPrefix + command} 1


*# Model List:*
1. DDIM
2. K_EULER
3. DPMSolverMultistep [Default]
4. K_EULER_ANCESTRAL
5. PNDM
6. KLMS` 

if (!(["1","2","3","4","5","6"]).includes(args[0])) throw `Masukan ID Model Yang benar.`
let aiModel
  if (args[0] == "1") { aiModel = "DDIM" }
  if (args[0] == "2") { aiModel = "K_EULER" }
  if (args[0] == "3") { aiModel = "DPMSolverMultistep" }
  if (args[0] == "4") { aiModel = "K_EULER_ANCESTRAL" }
  if (args[0] == "5") { aiModel = "PNDM" }
  if (args[0] == "6") { aiModel = "KLMS" }


   conn.AiImg = conn.AiImg ? conn.AiImg : {}
if (m.sender in conn.AiImg ) {
         await conn.reply(m.chat, '𝐢   Kamu masih ada session textToImage, harap selesaikan dahulu yang sebelumnya.', conn.verify[0])
         throw false
          }
          
let prompt = ''

const { key } = await conn.reply(m.chat, "> Replay this message and paste your prompt:",m)
conn.AiImg[m.sender] = {
      aiModel: aiModel,
      key,
      timeout: setTimeout(() => { conn.sendMessage(
      m.chat, { delete: key });
      delete conn.AiImg[m.sender];
        }, 160000)
    }
 }


handler.before = async (m, { conn }) => {
    conn.AiImg = conn.AiImg ? conn.AiImg : {}
    if (m.isBaileys || !(m.sender in conn.AiImg)) return;
   const {
        aiModel,
        key,
        timeout
    } = conn.AiImg[m.sender]
if (!m.quoted || m.quoted.id !== key.id || !m.text) return;

let res = await AI(m.text, aiModel)
	await conn.sendFile(m.chat, res, "aiImg.png", "*Your Prompt :*\n" + m.text, m)
 
conn.sendMessage(m.chat, { delete: key })
clearTimeout(timeout)
delete conn.AiImg[m.sender]
    
}
handler.help = ["text2anime"]
handler.tags = ['ai','xyz']
handler.command = /^(texttoanime|tta|text2anime)$/i
handler.premium = true

export default handler

async function AI(prompt, aiModel) {
    const replicate = new Replicate({
        auth: "r8_cRRoFSkk9lYr7ae9ijsiCv4WQ4TiF9u4TsymC"
    })
    const model =
        "cjwbw/anything-v3-better-vae:09a5805203f4c12da649ec1923bb7729517ca25fcac790e640eaa9ed66573b65"
    const input = {
        prompt: prompt,
        scheduler: aiModel
    }
    const output = await replicate.run(model, {
        input
    })
    return output
}